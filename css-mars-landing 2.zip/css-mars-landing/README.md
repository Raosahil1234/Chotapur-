# CSS Mars Landing

A Pen created on CodePen.io. Original URL: [https://codepen.io/mgitch/pen/PopJmL](https://codepen.io/mgitch/pen/PopJmL).

A little animation of a spaceship landing on what may not have been an uninhabited planet.